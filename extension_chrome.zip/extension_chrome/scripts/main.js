  var sonidos=['alachuchesu.swf',
				'avispate-bonva.swf',
				'chanchan.swf',
				'chan.swf',
				'choromota.swf',
				'cqc-mono.swf',
				'cuek.swf',
				'dostor.swf',
				'hermana.swf',
				'pesho-pesho.swf',
				'soporte-tecnico.swf',
				'vieja-culia.swf',
				'wena-naty.swf',
				'zafradas.swf',
				'be_my_lover.mp3'
				,'me_voy_a_la_mierda.mp3'
				,'dios_te_bendiga.mp3'
				,'hecha_mierda.mp3'

				]